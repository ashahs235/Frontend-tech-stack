
public class A {
    public void add()
    {
        System.out.println("hi");
    }
}
