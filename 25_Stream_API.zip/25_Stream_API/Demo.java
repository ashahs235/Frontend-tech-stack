import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class Demo
{
    public static void main(String[] args) 
    {
        List<Integer> nums = Arrays.asList(4, 5, 6, 3, 8, 7);

        //Stream is an interface, stream() is a method that returns object of stream
        //whatever changes are made to stream don't affect the nums
        Stream<Integer> s1 = nums.stream();
        System.out.println(s1); //java.util.stream.ReferencePipeline$Head@36baf30c

        //Stream can't be reused : like flowing water
        //s1.forEach(n -> System.out.println(n));

        //error at 2nd time
        // Exception in thread "main" java.lang.IllegalStateException: stream has already been operated upon or closed
        // at java.base/java.util.stream.AbstractPipeline.sourceStageSpliterator(AbstractPipeline.java:279)
        // at java.base/java.util.stream.ReferencePipeline$Head.forEach(ReferencePipeline.java:762)
        // at Demo.main(Demo.java:20)
        //s1.forEach(n -> System.out.println(n));

        //while printing s2, COMMENT s1

        //benefits of stream : stream has many methods
        Stream<Integer> s2 = s1.filter(n -> (n%2==0));
        //s2.forEach(n -> System.out.println(n));

        Stream<Integer> s3 = s2.map(n -> n*2);
        //s3.forEach(n -> System.out.println(n));

        //reduce() gives one value, so it's not stream
        int separatedResult = s3.reduce(0, (c, e) -> c+e);
        System.out.println("separatedResult " + separatedResult); //mapped value : 8, 12, 16

        int combinedResult = nums.stream()
                                 .filter(n->n%2==0)
                                 .map(n -> n*2)
                                 .reduce(0, (c, e) -> c+e);

        System.out.println("combinedResult " + combinedResult);
            
    }
}