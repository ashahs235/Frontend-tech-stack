import java.util.*;
import java.util.stream.*;

class Employee {
    String name;
    Date dateOfBirth;
    Address address;

    public Employee(String name, Date dateOfBirth, Address address) {
        this.name = name;
        this.dateOfBirth = dateOfBirth;
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public Address getAddress() {
        return address;
    }
}

class Address {
    String houseName;
    int houseNumber;

    public Address(String houseName, int houseNumber) {
        this.houseName = houseName;
        this.houseNumber = houseNumber;
    }

    public String getHouseName() {
        return houseName;
    }
}

public class EmployeeAddressStreamApi {
    public static void main(String[] args) {
        List<Employee> employees = Arrays.asList(
            new Employee("Alice", new Date(), new Address("Green Villa", 101)),
            new Employee("Bob", new Date(), new Address("Blue Haven", 102)),
            new Employee("Anil", new Date(), new Address("Sunrise Cottage", 103))
        );

        List<String> houseNames = employees.stream()
            .filter(e -> e.getName().startsWith("A"))
            .map(e -> e.getAddress().getHouseName())
            .collect(Collectors.toList());

        houseNames.forEach(System.out::println);
    }
}
