import java.util.*;
import java.util.stream.Collectors;

class Employee {
    private int id;
    private String name;
    private String department;
    private double salary;

    public Employee(int id, String name, String department, double salary) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.salary = salary;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getDepartment() { return department; }
    public double getSalary() { return salary; }

    @Override
    public String toString() {
        return "{ID=" + id + ", Name=" + name + ", Department=" + department + ", Salary=" + salary + "}";
    }
}

public class EmployeeStream {
    public static void main(String[] args) {
        List<Employee> employees = Arrays.asList(
            new Employee(1, "Alice", "IT", 75000),
            new Employee(2, "Bob", "IT", 80000),
            new Employee(3, "Charlie", "HR", 60000),
            new Employee(4, "David", "HR", 65000),
            new Employee(5, "Eve", "Finance", 90000),
            new Employee(6, "Frank", "Finance", 85000)
        );

        // Find the highest-paid employee in each department
        Map<String, Optional<Employee>> highestPaidByDepartment = employees.stream()
            .collect(Collectors.groupingBy(
                Employee::getDepartment, 
                Collectors.maxBy(Comparator.comparingDouble(Employee::getSalary))
            ));

        // Print highest-paid employee in each department
        highestPaidByDepartment.forEach((department, employee) -> 
            employee.ifPresent(emp -> System.out.println("Highest Paid in " + department + ": " + emp))
        );
    }
}
