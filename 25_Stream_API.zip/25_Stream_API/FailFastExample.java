import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

public class FailFastExample {
    public static void main(String[] args) {
        // ArrayList<String> list = new ArrayList<>();
        // list.add("Java");
        // list.add("Python");

        // Iterator<String> iterator = list.iterator();

        // while (iterator.hasNext()) {
        //     System.out.println(iterator.next());
        //     list.add("C");  // Modifying list during iteration
        // }


        // CopyOnWriteArrayList<String> list = new CopyOnWriteArrayList<>();
        // list.add("Java");
        // list.add("Python");

        // Iterator<String> iterator = list.iterator();

        // while (iterator.hasNext()) {
        //     System.out.println(iterator.next());
        //     list.add("C++");  // No exception
        // }

        // System.out.println("Final List: " + list);

        // ConcurrentHashMap<Integer, String> map = new ConcurrentHashMap<>();
        // map.put(1, "Java");
        // map.put(2, "Spring");
        // map.put(3, "Microservices");

        // // Iterating while modifying the map
        // for (Integer key : map.keySet()) {
        //     System.out.println(key + " -> " + map.get(key));
        //     map.put(4, "Hibernate"); // Adding new element during iteration
        // }

        // System.out.println("Final Map: " + map);

        A a = new A();
        A b = new A();

        Set<Object> set = new HashSet<>();
        set.add(a);
        set.add(b);

        System.out.println("Set size: " + set.size()); //Set size: 2
        System.out.println("Set size: " + set); //Set size: [A@36baf30c, A@7a81197d]

        Set<Integer> uniqueNumbers = Arrays.asList(1, 2, 3, 3, 4, 5, 5).stream()
        .collect(Collectors.toSet());

        System.out.println("unique " + uniqueNumbers);


        List<Integer> numbers = Arrays.asList(10, 20, 30, 40, 10, 50, 30, 60, 20);

        Set<Integer> unique = new HashSet<>();
        Set<Integer> duplicates = new HashSet<>();

        for (int num : numbers) {
            if (!unique.add(num)) { // If add() fails, it's a duplicate
                duplicates.add(num);
            }
        }

        System.out.println("Duplicate Elements: " + duplicates);
    

    }
}
