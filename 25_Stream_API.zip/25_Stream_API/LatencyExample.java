public class LatencyExample {
    public static void main(String[] args) {
        long startTime = System.nanoTime(); // Start time

        // Some operation (Example: Sorting)
        int[] arr = {5, 3, 8, 1, 2};
        java.util.Arrays.sort(arr);

        long endTime = System.nanoTime(); // End time
        long latency = endTime - startTime; // Calculate latency

        System.out.println("Execution latency (nanoseconds): " + latency);
    }
}
