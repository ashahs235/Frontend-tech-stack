// find the first repeated character and second repeated in it using Stream functions
 
// output :a and r
 
// String str="Java Articles are Awesome"
 
// String str="Java Articles are Awesome"
 
// output :a and r

import java.util.*;
import java.util.stream.*;

public class Repetition
{
    public static void main(String[] args) {
        String str="Java Articles are Awesome";
        Set<Character> seen = new HashSet<>();
        List<Character> repeated = str.chars()
							   .mapToObj(c->(char) c)
							   .filter(ch->ch != ' ')
                               .filter(ch->!seen.add(ch))
                               .distinct()
                               .collect(Collectors.toList());

        if(repeated.size() >= 2)
        {
            System.out.println("first repeated character is " + repeated.get(0));
            System.out.println("second repeated character is " + repeated.get(1));
        }
        else if(repeated.size() == 1)
        {
            System.out.println("first repeated character is " + repeated.get(0));
            System.out.println("second repeated character is not present");
        }
        else
        {
            System.out.println("no repetition");
        }
    }
}