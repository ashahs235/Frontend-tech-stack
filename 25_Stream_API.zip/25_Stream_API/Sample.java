import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

class Employee {
    private String name;
    private int salary;
    String department;

    // Constructor
    public Employee(String name, int salary, String department) {
        this.name = name;
        this.salary = salary;
        this.department = department;
    }

    // Getters
    public String getName() {
        return name;
    }

    public int getSalary() {
        return salary;
    }

    // toString() for easy printing
    @Override
    public String toString() {
        return name + " : " + salary;
    }
}

public class Sample {
    public static void main(String[] args) {
        // List<String> strings = Arrays.asList("java scala ruby", "java react spring java");
        // String word = "java";

        // // Find occurrences of "java"
        // List<String> result = strings.stream()
        //         .filter(s -> s.contains(word))
        //         .collect(Collectors.toList());

        // System.out.println("Strings containing '" + word + "': " + result);


        List<Employee> employees = Arrays.asList(
            new Employee("Alice", 95000, "Engineering"),
            new Employee("Bob", 120000, "Engineering"),
            new Employee("Charlie", 85000, "Sales"),
            new Employee("David", 105000, "Marketing"),
            new Employee("Eve", 130000, "Finance"),
            new Employee("Frank", 75000, "Sales")
        );

        // 🔹 Filtering employees with salary > 50000 using Stream API
        // List<Employee> highSalaryEmployees = employees.stream()
        //     .filter(emp -> emp.getSalary() > 50000)
        //     .limit(2)
        //     .collect(Collectors.toList());

        // // 🔹 Printing the result
        // System.out.println("Employees with salary > 50000:" + highSalaryEmployees);
        // highSalaryEmployees.forEach(System.out::println);

        Map<String, List<Employee>> top2HighSalaryEmployees = employees.stream()
        .filter(emp -> emp.getSalary() > 50000)
        //.sorted(Comparator.comparingInt(Employee::getSalary).reversed()) // Sort by salary (descending)
        //.limit(2) // Pick top 2
        .collect(Collectors.groupingBy(emp -> emp.department));

    System.out.println(top2HighSalaryEmployees);

    }
}
