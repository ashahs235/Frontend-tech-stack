import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

class Student {
    private int id;
    private String name;
    private LocalDate dob;

    public Student(int id, String name, LocalDate dob) {
        this.id = id;
        this.name = name;
        this.dob = dob;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public LocalDate getDob() { return dob; }

    @Override
    public String toString() {
        return "Student{id=" + id + ", name='" + name + "', dob=" + dob + '}';
    }
}

public class StudentData {
    public static void main(String[] args) {
        // Step 1: Create Student objects
        Student s1 = new Student(1, "ABC", LocalDate.of(2000, 10, 23));
        Student s2 = new Student(2, "XYZ", LocalDate.of(1999, 5, 12));
        Student s3 = new Student(3, "PQR", LocalDate.of(2001, 3, 8));

        // Step 2: Add to List
        List<Student> studentList = Arrays.asList(s1, s2, s3);

        // Step 3: Convert to Map (key = id, value = student object)
        Map<Integer, Student> studentMap = studentList.stream()
                .collect(Collectors.toMap(Student::getId, student -> student));

        // Print the map
        studentMap.forEach((id, student) -> System.out.println(id + " => " + student));
    }
}

