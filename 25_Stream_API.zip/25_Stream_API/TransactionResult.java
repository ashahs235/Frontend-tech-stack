import java.util.*;
import java.util.stream.*;
import java.time.LocalDate;

public class TransactionResult {

    static class Transaction {
        private String city;
        private LocalDate date;
        private int amount;

        public Transaction(String city, String date, int amount) {
            this.city = city;
            this.date = LocalDate.parse(date);
            this.amount = amount;
        }

        public String getCity() { return city; }
        public LocalDate getDate() { return date; }
        public int getAmount() { return amount; }

        @Override
        public String toString() {
            return "Transaction{" + city + ", " + date + ", " + amount + "}";
        }
    }

    public static void main(String[] args) {
        List<Transaction> transactions = Arrays.asList(
            new Transaction("Mumbai", "2022-01-01", 100),
            new Transaction("Mumbai", "2022-01-01", 200),
            new Transaction("Pune", "2022-01-02", 300),
            new Transaction("Pune", "2022-01-02", 400),
            new Transaction("Banglore", "2022-01-03", 500)
        );

        Map<String, Map<LocalDate, Integer>> result =
            transactions.stream()
                .collect(Collectors.groupingBy(
                    Transaction::getCity,
                    Collectors.groupingBy(
                        Transaction::getDate,
                        Collectors.summingInt(Transaction::getAmount)
                    )
                ));

        // Print the result
        result.forEach((city, dateMap) -> {
            System.out.println(city + ":");
            dateMap.forEach((date, totalAmount) ->
                System.out.println("  " + date + " -> " + totalAmount)
            );
        });
    }
}
