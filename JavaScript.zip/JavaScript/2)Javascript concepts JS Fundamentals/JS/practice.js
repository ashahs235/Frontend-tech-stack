let firstName = "Mark";
let profession = "Developer";
let age = 20;
console.log(firstName, "is a", profession);

let completeString = firstName + profession;
console.log(completeString);

completeString = firstName + " is a " + profession;
console.log(completeString); //no longer preferred

completeString = firstName + " is a " + profession + " who is "+ age + " years of age "; // to avoid this, ``
console.log(completeString);

let newCompleteString = `${firstName} is a new good ${profession} who is ${age} years old`; //easy
console.log(newCompleteString);

