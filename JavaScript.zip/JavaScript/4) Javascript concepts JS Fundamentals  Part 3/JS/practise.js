let seconds = 0;
function incrementSeconds() //executed only once
{
    ++seconds;
    console.log(`The current value of seconds is : ${seconds}`);
}

//incrementSeconds();
//setInterval(incrementSeconds, 1000)

let d = new Date();
//console.log(d);
//console.log(d.toLocaleTimeString());

function myTimer()
{
    var d = new Date();
    var t = d.toLocaleTimeString();
    console.log(t);
}

//myTimer();
//setInterval(myTimer, 1000)

let timerPrinter = setInterval(myTimer, 1000);
clearInterval(timerPrinter)

// setTimeout(function() //clear/stop after a particular time
// {
//     clearInterval(timerPrinter);
// }, 5000); 