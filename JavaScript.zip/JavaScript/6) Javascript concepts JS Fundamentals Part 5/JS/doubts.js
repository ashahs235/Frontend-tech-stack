//Old concepts

const fruits = ["Banana", "Orange", "Apple", "Mango"];
//fruits.sort();    
console.log(fruits);
fruits.reverse();
console.log(fruits);

//https://stackoverflow.com/questions/28527712/how-to-add-key-value-pair-in-the-json-object-already-declared
obj = {
    "1":"aa",
    "2":"bb"
};

var newNum = "3";
var newVal = "cc";
obj[newNum] = newVal;
//alert(obj["3"]);
console.log(obj);
obj["4"] = "dd";
console.log(obj);
delete obj["4"];
console.log(obj);


//Please try following simple operations on a json, insert/update/push:
console.log(" ");
var movie_json = {
                    'id': 100,
                 };

//to insert new key/value to movie_json
movie_json['name'] = 'Harry Potter';
console.log("new key: " + movie_json);
console.log( movie_json);

//to update a key/value in movie_json
movie_json['id'] = 101;
//console.log("updated key: " +movie_json);

//adding a json array to movie_json and push a new item.
movie_json['movies']=["The Philosopher's Stone"];
console.log(movie_json);
movie_json['movies'].push('The Chamber of Secrets');
console.log(movie_json);

//https://jsfiddle.net/shrawanlakhe/78yd9a8L/4/ - object is added for every click


