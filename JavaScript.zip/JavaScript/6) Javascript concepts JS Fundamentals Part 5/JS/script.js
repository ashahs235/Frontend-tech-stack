//Normal function definition
function sumOfNumbers(firstNumber, secondNumber)
{
    return firstNumber + secondNumber; //instead of console.log - returns output of the function
    //console.log(firstNumber + secondNumber);
}
sumOfNumbers(2, 2); //does not print
console.log(sumOfNumbers()); //NaN
console.log(sumOfNumbers(5, 6));  //to print o/p
const sumOfTwoNumbers = sumOfNumbers(4, 6); //define & assign func
console.log("The sum of 2 numbers is : ", sumOfTwoNumbers);

//Definition using variables - define & assign func at a time
// const sumOfTwoNumbers = function(firstNumber, secondNumber) //no func name, use func without writing func name
// {
//     return firstNumber+secondNumber;
// }
// sumOfTwoNumbers(2, 2); //does not print
// console.log(sumOfTwoNumbers); //function code
// console.log(sumOfTwoNumbers()); //NaN
// console.log(sumOfTwoNumbers(3, 4)); //7


//Arrow function (another way - ES2021-- ECMAScript) - no func keyword, flat arrow is written =>
const sumOfTwoNewNumbers = (firstNumber, secondNumber) => {
    return firstNumber+secondNumber;
}
//console.log(sumOfTwoNewNumbers(30, 4));

const areaOfCircle = (radius) => {
    return 3.14 * radius * radius;
}
//console.log(`area of circle is ${areaOfCircle(5)}`);


//Simple Closure - nested function - func inside func - parent & child func
//Nested Functions - 1
// function areaAndDiameterOfCircle(radius)
// { //scope - accessible boundary
//     const passedRadiusValue = radius; //this variable is accessible to child func but not outside the func (private)
//     console.log("radius value in parent func", passedRadiusValue);
//     function areaOfCircle() //no parameter here bcoz parameter is in parent func
//     {
//         console.log("radius value in child func", passedRadiusValue);
//         return 3.14 * passedRadiusValue * passedRadiusValue;
//     }
//     areaOfCircle(); //outer func radius is accessible for inner func
//     console.log(passedRadiusValue);
// }
// //console.log(passedRadiusValue); //error - can't access outside

// areaAndDiameterOfCircle(4);

//Nested func 2
function areaAndDiameterOfCircle(radius)
{ 
    const passedRadiusValue = radius; 
    console.log("radius value in parent func", passedRadiusValue);
    //nested func for area
    function areaOfCircle() 
    {
        console.log("radius value in child func", passedRadiusValue);
        return 3.14 * passedRadiusValue * passedRadiusValue;
    }
    //nested func for diameter
    function diameterOfCircle()
    {
        return 2 * radius;
    }
    const area = areaOfCircle();
    const diameter = diameterOfCircle();
    console.log("values", area, diameter);
    const areaDiameterJSON = { //to fetch both radius & diameter - different properties of circle - JSON
        //'area': areaOfCircle() //pass functions as values
        // 'area': area, //original - variable name
        // 'diameter':diameter // same name for key & value  

        //so another way
        //It's called destructured syntax - remove some structure from JSON & use it directly
        //if key & variable names are same -> don't write key name, write variable name directly 
        //bcoz JS takes care of assigning name of the key by itself & it (JS) assigns value - see o/p
        area,  //shorthand syntax
        diameter //if one variable is removed, JSON still prints with one key value pair
    }
    console.log("JSON is", areaDiameterJSON); //key value
    return areaDiameterJSON;
}


// areaAndDiameterOfCircle(4); 
// console.log(areaAndDiameterOfCircle(4));

//to access only area value
const areaAndDiameter = areaAndDiameterOfCircle(4); //.area
console.log("Only area", areaAndDiameter.area); //area from o/p of the JSON 
console.log(areaAndDiameterOfCircle); //func is printed
console.log(" ");
console.dir(areaAndDiameterOfCircle); //func is printed in a better way
console.log(" ");
console.dir(areaAndDiameterOfCircle(7)); //
console.log(" ");

