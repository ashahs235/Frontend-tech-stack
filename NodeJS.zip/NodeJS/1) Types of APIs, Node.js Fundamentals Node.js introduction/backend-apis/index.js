//Step 1 : Import HTTP Module
const http = require("http");

//Step 2
//createServer : like task manager in windows/activity monitor in mac
//creates process : localhost:3000 - http ports, nodejs 8080
//request, response : to get data from server side, response to send to server side

http.createServer(function(req, res)
{
    console.log("Server Started");
    console.log("request body", req);
    console.log("response body", res);
    //res.write("Hello World"); 

    //Step 3 : Set the Header
    //Send JSON response in nodejs - through HTML tags 
    res.setHeader('Content-type', 'application/json'); //if text/html
    const data = {"name":"KGF", "characterName":"Rocky"};
    const dataIntoString = JSON.stringify(data);
    console.log("log 1", dataIntoString);
    console.log("log 2", data);
    console.log("Type of data variable", typeof dataIntoString);
    //Step 4 : Send d data using response.write
    res.write(dataIntoString); //data - error bcoz JSON directly can't be sent to res.write, res.write accepts data in string format always, 
    //so inbuilt stringify() JSON
    //res.write("<h1>Hello World!</h1>"); //if text/html
    res.end();
}).listen(8080);



//like
// const array = ["one", "two"]
// array.map(function(item)
// {

// })