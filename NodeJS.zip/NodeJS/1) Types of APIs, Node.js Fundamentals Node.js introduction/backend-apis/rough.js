const data = {"name":"KGF"};
    const dataIntoString = JSON.stringify(data);
    console.log("log 1", dataIntoString);
    console.log("log 2", data);
    console.log("Type of data variable", typeof dataIntoString);

    console.log(module);