function addNumbers(firstNumber, secondNumber)
{
    return firstNumber + secondNumber;
}

const valueOfPie = 3.14;
// export function in nodejs
module.exports.addNumbers = addNumbers;
// const exportObject = {};
// exportObject.addNumbers = addNumbers; //-- module.exports.addNumbers = addNumbers;

module.exports.valueOfPie = valueOfPie //LHS valueOfPie should be in index.js addNumbersFile.valueOfPie
console.log(module.exports); //empty obj in terminal