//import { } from "module"; --importing any file in React project

//import file in nodejs
const addNumbersFile = require("./addNumbers");

// console.log("Hello World");

// function addNumbers (a, b)
// {
//     return a + b;
// }

// console.log(addNumbers(2, 3));

// Module in node.js -- inbuilt
console.log("module is", module);
console.log("file", addNumbersFile); //entire file
console.log("function call", addNumbersFile.addNumbers(2, 3)); //individually
console.log("value", addNumbersFile.valueOfPie);