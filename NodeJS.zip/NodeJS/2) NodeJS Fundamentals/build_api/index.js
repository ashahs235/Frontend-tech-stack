//Step 1 : Import HTTP & URL Module
const http = require('http'); //import http module
const url = require('url'); //import url module - used to parse data in d form of url
const fs = require("fs"); //built in nodejs module - readFile 
const areaOfCircleFile = require("./routes/areaOfCircle.js");
const areaOfTriangleFile = require("./routes/areaOfTriangle.js");
const fruitsDataFile = require("./routes/fruitsData.js");

//Parse : method convert one format of data into another

//create server function
// http.createServer(function(req, res){
//     console.log(req.query, req.url); //undefined for req.query bcoz no response initially, req.url : favicon..
//     console.log("Req.url", req.url); //calculateArea..
//     res.write("Hello world"); //to print on browser
//     res.end(); //to end the response process
// }).listen(8085);

http.createServer(function(req, res){
    //path variables
    const path = req.url;

    const urlData = url.parse(path, true); //true : to get key value pair like JSON, if true is not there : url browser key value pair
    
    console.log("'path'", path); //"Hi 'friends'"
    console.log("-'urlData'-", urlData, "'query'", urlData.query); //query : url data from frontend
    console.log("'Parsed data'", url.parse(path)); //parsing url data from req param

    //query params from path
    const queryParamsObject = url.parse(path, true).query;
    console.log("'queryParamsObject'", queryParamsObject);

    //creating routes --Route 1
    // if (path.includes("calculateAreaOfCircle"))
    // {
    //     console.log("radius value", queryParamsObject.radius);
    //     const radius = queryParamsObject.radius;
    //     const areaOfCircle = Math.PI * radius * radius;
    //     console.log("area of circle File", areaOfCircle);
    //     const responseObject = {
    //         area : areaOfCircle,
    //     }
    //     //response object
    //     res.setHeader("Content-Type", "application/json"); //comment & see
    //     res.write(JSON.stringify(responseObject));
    //     res.end();
    // }

    if (path.includes("calculateAreaOfCircle"))
    {
        console.log("radius value", queryParamsObject.radius);
        const radius = queryParamsObject.radius; //radius is obtained by req obj
        
        // no need : console.log("area of circle File", areaOfCircleFile);
        areaOfCircleFile.areaOfCircleRoute(radius, res); //pass res - func call
        
        //response object
        
    }

    //Route 2.. 10 routes more code : so modules concept
    // else if(path.includes("calculateAreaOfTriangle"))
    // {
    //     const base = queryParamsObject.base;
    //     const height = queryParamsObject.height;
    //     console.log("Base & Height are :", base, height);
    //     const areaOfTriangle = 0.5 * base * height;
    //     const responseObject = {
    //         areaOfTriangle : areaOfTriangle, //instead of key : value,  "areaOfTriangle" : areaOfTriangle -> key value same - write once
    //         //areaOfTriangle
    //     };
    //     //header : either html data or json data
    //     res.setHeader("Content-Type", "application/json");
    //     res.write(JSON.stringify(responseObject)); //string or JSON data
    //     res.end();
    // }

    else if(path.includes("calculateAreaOfTriangle"))
    {
        const base = queryParamsObject.base;
        const height = queryParamsObject.height;
        console.log("Base & Height are :", base, height);
        areaOfTriangleFile.areaOfTriangle(base, height, res);
        //header : either html data or json data
        
    }

    // else if(path.includes("fruitsData"))
    // {
    //     console.log("Dir name:", __dirname, "/data/fruitsData.json");
    //     //address of JSON file : gives address of the current folder : till build_api
    //     const pathString = `${__dirname}/data/fruitsData.json`; //name of the file
    //     //addres of JSON file
    //     console.log("pathString is ", pathString);
    //     //readfile has 2 params : file path or url of file & callback func (func returned in 2nd param)
    //     //map function - error & data params
    //     //readFile : read a file from local project directory
    //     fs.readFile(pathString, function(err, data){
    //         console.log("Err", err,  "data is", data); //raw data : buffer data
    //         console.log(JSON.parse(data)); //proper JSON format : JSNO.parse is used to convert any kind of data into JSON obj
            
    //         //converting buffer data to JSON object
    //         const dataFromFile = JSON.parse(data);
    //         console.log(dataFromFile.results);
    //         //send data back to client end
    //         res.setHeader("Content-Type", "application/json");
    //         res.write(JSON.stringify(dataFromFile)); //converts JSON obj to string
    //         res.end();
    //     });
    //     // res.write("Success"); 
    //     // res.end(); //remove
    //}

    else if(path.includes("fruitsData"))
    {
        console.log("Dir name:", __dirname, "/data/fruitsData.json");
        //address of JSON file : gives address of the current folder : till build_api
        const pathString = `${__dirname}/data/fruitsData.json`; //name of the file
        //addres of JSON file
        console.log("pathString is ", pathString);
        //readfile has 2 params : file path or url of file & callback func (func returned in 2nd param)
        //map function - error & data params
        //readFile : read a file from local project directory
        fruitsDataFile.fruitsDataRoute(pathString, res); //res is to send data to client , fs also as a param
        // res.write("Success"); 
        // res.end(); //remove
    }


    else
    {
        res.setHeader("Content-Type", "text/html");
        res.write("<h1>Hello world</h1>"); //preview in postman
        res.write("<h2>Site Description</h2>")
        res.end();
    }
}).listen(8080);

console.log("Dir name:", __dirname);

const inputString = `{"technology" : "JavaScript"}`;
const stringIntoJSON = JSON.parse(inputString); //converting any form into JSON
console.log("inputString : ", inputString.technology);
console.log("stringIntoJSON : ", stringIntoJSON.technology);
