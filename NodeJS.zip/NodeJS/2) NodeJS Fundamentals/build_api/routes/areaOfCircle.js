// slash ** enter -- better way to write comments

/**
 * Function to calculate area of circle (click enter)
 * & send back the response to client
 * @param {*} radius 
 * @param {*} res 
 */

function areaOfCircleRoute(radius, res)
{
    //calculate area of circle
    const areaOfCircle = Math.PI * radius * radius;
    const responseObject = {
        area : areaOfCircle,
    }
    //return responseObject;
    res.setHeader("Content-Type", "application/json"); //comment & see
    res.write(JSON.stringify(responseObject));
    res.end();
}

module.exports.areaOfCircleRoute = areaOfCircleRoute;