//Step 1 : require express
const express = require("express");

//step 2 : create an instance of expressjs
const app = express();

const port = 8081;
//step 3 : Handling primary route
app.get("/", function(request, response){
    response.send("Backend apis");
});

//step 4 : start server on a port
app.listen(8081, function(){
    console.log("local server started on localhost");
})
