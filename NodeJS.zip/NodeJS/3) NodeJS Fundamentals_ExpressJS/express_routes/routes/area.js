const express = require("express");

const router = express.Router();

router.get("/triangle", function(req, res){
    console.log(req);
    console.log("Values from clients", req.query); //query params in expressJS
    const base = req.query.base;
    const height = req.query.height;
    const areaOfTriangle = 0.5 * base * height;
    res.send({
        result: areaOfTriangle,
    })
});

module.exports = router; 