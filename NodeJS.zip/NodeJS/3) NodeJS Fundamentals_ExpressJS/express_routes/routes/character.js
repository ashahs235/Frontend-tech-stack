//step 1: import express & create an instance of router
const express = require('express');

//Step 1 for writing files : imported fs module from nodejs
const fs = require("fs");

const router = express.Router();

console.log("Current directory for saving data", `${__dirname}/data`);
const folderPath = `${__dirname}/data`;

//step 2 : secondary route
//parent route : http://localhost:3000/character
router.get("/", function(req, res)
{
    res.send("Character secondary path");
});

//child route : http://localhost:3000/character/getCharacter
router.get("/getCharacter", function(req, res)
{
    res.send("Character data available here");
});

router.get("/getCharacterData", function(req, res)
{
    //res.send("Character data available here");
    fs.readFile(`${folderPath}/character.json`, function(err, data){
        if(err)
        {
            console.log(err);
        }
        else
        {
            // console.log("data read from file", data); //buffer data
            // res.send({"results" : "data read successfully"});

            const dataFromFile = JSON.parse(data); //to read the file properly, to write : stringify
            console.log("data read from file", dataFromFile);
            //res.send({"results" : "data read successfully"});
            res.send({results: dataFromFile});
        }
    });
});

router.post("/createCharacter", function(req, res)
{
    console.log("Request:", req);
    console.log("Request body: Data from Client side : Postman or website side or mobile app",req.body);
    // step 2 :get data from postman
    const characterData = req.body;
    //step 3
    //to create file : character:json
    //use writeFile method
    fs.writeFile(`${folderPath}/character.json`, JSON.stringify(characterData), 
    function(err) 
    {
        if(err)
        {
            console.log("Error in writing file", err);
        }
        else
        {
            console.log("File written successfully");
            //res.send("Character created successfully");
            //beauty of ExpressJS is we can send JSON can be sent without stringify bcoz od express.json() in app.js 22
            res.send({"results" : "File/Character created successfully"});
        }
    });
    //res.send("Character created successfully"); //initially, later inside above else condition
});

//step 3 : export the router
module.exports = router;