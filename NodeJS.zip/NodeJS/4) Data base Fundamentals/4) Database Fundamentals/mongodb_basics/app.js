const express = require('express');

//step 1 : Importing mongoose module
const mongoose = require('mongoose'); //import mongoose

//step 2 : Make a connection
mongoose.connect("mongodb+srv://Asha:dinga@cluster0.7tinq.mongodb.net/CollegeDB?retryWrites=true&w=majority",
{
    useNewUrlParser: true,
    useUnifiedTopology: true,
    //useFindAndModify: false,
    //useCreateIndex: true, 
}, 
function(err)
{
    if(err)
    {
        console.log("err in connection is", err); 
    }
    else
    {
        console.log("Connection to database is made");
    }
}); 

const path = require('path');
const cookieParser = require('cookie-parser');
const logger = require('morgan'); //npm module for login purpose

const indexRouter = require('./routes/index');
const usersRouter = require('./routes/users');
const studentsRouter = require('./routes/student');
const charactersRouter = require('./routes/characters');

const app = express(); //server running here

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/students', studentsRouter);
app.use('/characters', charactersRouter);

module.exports = app;
