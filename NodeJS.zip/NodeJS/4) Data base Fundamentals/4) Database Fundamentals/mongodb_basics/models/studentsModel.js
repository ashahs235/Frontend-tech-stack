//step 1 :  Import schema from mongoose
const mongoose = require("mongoose");
const Schema = mongoose.Schema;

//Step 2 : write Schema & specify the data
const studentsSchema = new Schema({
    name  : String,
    branch : String,
    rollNo : Number
},
{collection : "StudentsCollection"});

//step 3 : export schema
module.exports = mongoose.model("StudentsCollection", studentsSchema);