const express =  require("express");
const router = express.Router();
const charactersModel = require('../models/charactersSchema.js');

router.get("/getData", function(req, res){
    charactersModel.find({}, function(err, data){
        if(err)
        {
            console.log("error occurred", err);
        }
        else
        {
            console.log("data from characters collection", data);
            res.send({results : data}); 
        }
    })
    //res.send("Data sent"); //comment after writing above res.send 
});

module.exports = router;