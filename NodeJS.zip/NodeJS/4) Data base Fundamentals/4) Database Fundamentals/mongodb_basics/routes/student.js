const express =  require("express");
const router = express.Router();
const studentsModel = require('../models/studentsModel.js');

router.get("/getData", function(req, res){
    studentsModel.find({}, function(err, data){
        if(err)
        {
            console.log("error occurred", err);
        }
        else
        {
            console.log("data from students collection", data);
            res.send({results : data}); 
        }
    })
    //res.send("Data sent"); //comment after writing above res.send
});

module.exports = router;