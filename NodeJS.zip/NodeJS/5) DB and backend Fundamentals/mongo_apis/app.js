const express = require('express');
const cors = require("cors"); //cors
require('dotenv').config(); //dotenv
const path = require('path');
const cookieParser = require('cookie-parser');
const logger = require('morgan');
const mongoose = require("mongoose");

const indexRouter = require('./routes/index');
const usersRouter = require('./routes/users');
const studentsRouter = require('./routes/students');


const app = express();

console.log("String in .env file", process.env.DB_URL_STRING); //check
mongoose.connect(
    //"mongodb+srv://Asha:dinga@cluster0.7tinq.mongodb.net/College?retryWrites=true&w=majority", //cut & paste in .env file bcoz of security purpose
    //after d string is cut & pasted in .env file, it's written here as
    process.env.DB_URL_STRING,
    { //json entries
        useNewUrlParser: true,
        useUnifiedTopology: true,
        //useFindAndModify: false,
        //useCreateIndex: true, 
    },
    function(err)
    {
        if(err)
        {
            console.log("err in connection is", err); 
        }
        else
        {
            console.log("Connection to database is made");
            //console.log(0, 01, 010, 021);
        }
    }
);

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public'))); //__dirname is mongo_apis folder, inside that public folder
app.use(cors()); //cors

app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/students', studentsRouter);

module.exports = app;
