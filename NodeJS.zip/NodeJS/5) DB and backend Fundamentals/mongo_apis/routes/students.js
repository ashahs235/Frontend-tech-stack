const express = require('express');
const router = express.Router();
const studentSchema = require("../models/students");
const fs = require('fs');

/**
 * POST req
 * router.post
 * inbuilt Mongoose method used is .save
 */
//students.js is the Route, createData is the path
router.post('/createData', function(req, res) 
{
    //To save d data into database in atlas
    console.log("records", req.body); 
    const studentsData = new studentSchema(req.body);
    studentsData.save(function(err)
    {
        if(err)
        {
            console.log("Error occured", err);
        }
        else
        {
            console.log("Data saved successfully");
            res.send("student entry added successfully"); 
        }
    });
   // res.send('student entry added successfully');
});

/**
 * GET req
 * router.get
 * inbuilt Mongoose method used is .find
 */
router.get("/getDetails", function(req, res)
{
    studentSchema.find({}, {_id: 0, __v:0},
    //studentSchema.find({'branch' : 'CSE'}, {_id: 0, __v:0}, //to search particular data
        function(err, data)
        {
            if(err)
            {
                console.log("log of error", err); 
            }
            else
            {
                //to store data in file
                fs.writeFile(
                // "studentDetails.json", //in root folder
                `${__dirname}/studentDetails.json`,   //inside route folder
                JSON.stringify({results : data}),
                    function (params)
                    {
                        if(err)
                        {
                            console.log("err", err);
                        }
                        else
                        {
                            console.log("File Saved Successfully");
                        }
                    }
                );
                res.send({results : data});
            }
        });
        
});

/**
 * PUT req
 * router.put
 * inbuilt Mongoose method used is .findOneAndUpdate
 */
router.put("/updateDetails", function (req, res)
{
    console.log("req.body is", req.body);
    //to update in database
    studentSchema.findOneAndUpdate(
        {
            //find Data 
            rollNo : req.body.rollNo //search param is 1st one
        },
        {
            //record that needs to be updated
            branch : req.body.branch
        },
        {
            //internal params
            new: true,                       // return updated doc
            runValidators: true              // validate before update
        },
        //callback func
        function(err)
        {
            if(err)
            {
                console.log(err);
            }
            else
            {
                res.send("Student details updated successfully");
            }
        }
    );
   // res.send("Student details updated successfully"); //comment later
});

/**
 * DELETE req
 * router.delete
 * inbuilt Mongoose method used is .findOneAndRemove or .deleteMany
 */
router.delete('/deleteStudentDetail', function(req, res)
{
    console.log(req.body);
    studentSchema.findOneAndRemove({'rollNo' : req.body.rollNo}, // to delete one record
    //studentSchema.deleteMany({}, //deletes all records
        function(err)
        {
            if(err)
            {
                console.log(err);
            }
            else
            {
                res.send("Data deleted successfully");
            }
        });
    //res.send("Data deleted successfully"); //comment later
});

module.exports = router;