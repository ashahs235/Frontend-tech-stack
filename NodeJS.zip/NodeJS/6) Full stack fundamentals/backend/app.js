const express = require('express');
const cors = require("cors"); //cors
require('dotenv').config(); //dotenv
const path = require('path');
const cookieParser = require('cookie-parser');
const logger = require('morgan');
const mongoose = require('mongoose'); //mongoose
const indexRouter = require('./routes/index');
const usersRouter = require('./routes/users');
const groceryRouter = require('./routes/grocery');

const app = express();

mongoose.connect(
   // "mongodb+srv://Asha:dinga@cluster0.7tinq.mongodb.net/groceryDB?retryWrites=true&w=majority", //cut & paste in .env file bcoz of security purpose
    //after d string is cut & pasted in .env file, it's written here as
    process.env.MONGO_SERVER_URL,
    { //json entries
        useNewUrlParser: true,
        useUnifiedTopology: true,
        //useFindAndModify: false,
        //useCreateIndex: true, 
    },
    function(err) //callback function
    {
        if(err)
        {
            console.log("err in connection is", err); 
        }
        else
        {
            console.log("Connection to database is made");
            //console.log(0, 01, 010, 021);
        }
    }
);

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(cors()); //cors

app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use("/grocery", groceryRouter);

module.exports = app;
