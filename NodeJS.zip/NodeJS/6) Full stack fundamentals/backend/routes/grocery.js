const express = require("express");
const router = express.Router();
const GroceryModel = require("../models/grocery"); //schema

/**
 * Creation of grocery items using POST method
 * 
 */
router.post('/add', function(req, res){
    console.log(req.body); //req.body is what is passed in POSTMAN body : JSON
    const groceryItem = new GroceryModel(req.body); //create the instance of the model
    groceryItem.save(function(err)
    {
        if(err)
        {
            console.log("Error is", err);
            //sending the error status in api
            res.status(400).send({
                message : err,
            });
        }
        else
        {
            res.send("Grocery item added successfully");
        }
    });
    //res.send("Grocery item added successfully"); //comment later
});


/**
 * API to list all items
 */
router.get("/getAll", function(req, res)
{
    GroceryModel.find({}, {__v : 0}, function(err, data) //find({} this 1st entry is used to find particular data : id is passed)
    {
        if(err)
        {
            console.log("Error is", err);
            res.status(400).send({
                message : err,
            });
        }
        else
        {
            console.log("Data is", data);
            //res.send("Data from db");
            res.send({results : data});
        }
    });
});

/**
 * PUT req, updatePurchaseStatus route
 */
router.put("/updatePurchaseStatus", function(req, res)
{
    GroceryModel.findOneAndUpdate
    (
        {
            //find id
            '_id' : req.body._id
        },

        {
            //update
            'isPurchased' : true
        },
        function(err)
        {
            if(err)
            {
                console.log("Error is", err);
                res.status(400).send({
                    message : err,
                });
            }
            else
            {
                res.send("Purchased status updated successfully");
            }
        }
    );
});


/**
 * DELETE Req
 */
router.delete("/deleteGroceryItem", function(req, res)
{
    const groceryItemId =  req.body._id;
    GroceryModel.remove({_id: groceryItemId}, function(err)
    {
        if(err)
        {
            console.log("Error is", err);
            res.status(400).send({
                message : err,
            });
        }
        else
        {
            res.send({"result" : "Grocery Item removed successfully"});
        }
    });
});

module.exports = router;

