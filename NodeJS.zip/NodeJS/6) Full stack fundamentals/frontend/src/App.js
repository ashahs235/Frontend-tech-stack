import './App.css';
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import {PrivateRoute} from "./utils/PrivateRoute.js";
import {Header} from "./components/Header";
import {GrocerySection} from "./components/GrocerySection";
import {RegistrationForm} from "./components/RegistrationForm";
import {LoginForm} from "./components/Loginform";
import React from 'react';

function App() {
  console.log(localStorage.getItem("user Token"));
  return (
    <Router>
      <div className="App">
        {/* instance of header */}
        <Header/>
       {/* <Routes>
      <Route element={<PrivateRoute />}>
          <Route path="/home" element={<GrocerySection />} exact={true}/>
        </Route>
      </Routes> */}
      {/* <Routes> */}
        {/* <PrivateRoute path="/home" element={<GrocerySection />} /> */}
       {/* <Route path='/home' element= {<PrivateRoute> <GrocerySection />
         </PrivateRoute>}/> */}
         {/* Error bcoz PrivateRoute is not a Route component */}
         {/* <Route element={<PrivateRoute />}>
          <Route path="/home" element={<GrocerySection />} />
    </Route> */}
      {/* </Routes> */}
        {/* PrivateRoute for home page changed from below <Route> */}
         <Routes>
         
         <Route path="/home" element={<GrocerySection props={"hi"}/>}/>
          {/* commented below line bcoz component name is added above */}
          {/* <GrocerySection /> */}
          </Routes> 
      <Routes>
        <Route path="/register" element={<RegistrationForm/>}/>  
      </Routes>
      <Routes>
        <Route path="/login" element={<LoginForm/>}/>  
      </Routes>
      </div>
    </Router>
  );
}

export default App;
