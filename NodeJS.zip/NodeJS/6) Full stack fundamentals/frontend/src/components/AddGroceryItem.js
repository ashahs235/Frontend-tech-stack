import {useState} from "react";
import axios from "axios";

//props, destructuring for our props
export function AddGroceryItem({baseUrl, fetchGroceryItems})
{
    const [groceryInputText, updateGroceryInputText] = useState(""); //user input
    console.log("updated state variable", groceryInputText); 
    async function handleAddingItems()
    {
        const createTask = await axios.post(`${baseUrl}/grocery/add`, 
        {
                //"groceryItem" : "oranges",
                "groceryItem" : groceryInputText, //user input
                "isPurchased" : false
        });
        console.log("CreateTask", createTask);
        alert("Grocery Item added successfully");
        updateGroceryInputText(""); //reset the textbox to empty
        fetchGroceryItems(); //to make API call & update the list without refreshing,
        // useEffect also can be used but in useEfect, the responsibility of updating data lies on frontend & array [groceryItems] has to be updated manually which is not good
        //so fetchGroceryItems() gets data from backend section
    }
    return( 
    <div>
        <div className="input-group mb-3">
            <input type="text" className="form-control" placeholder="Grocery Item" 
            aria-label="Grocery Item" 
            value={groceryInputText}
            onChange={(e) => updateGroceryInputText(e.target.value)} //event
            />
            <button className="input-group-text btn btn-primary" id="basic-addon2"
            onClick={() => handleAddingItems()}
            >Add Grocery Item</button>
        </div> 
    </div>);

}