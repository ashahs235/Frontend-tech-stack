//initial code

// import {AddGroceryItem} from "./AddGroceryItem";

// export function GrocerySection()
// {
//     return(
//         <div className="d-flex justify-content-center align-items-center flex-column">
//             <h1>Grocery Planning Section</h1>
//             <AddGroceryItem />
//         </div>
//     );
// }


/**
 * Module to show grocery section in app
 */
//Later Code
//step 1
import {useEffect, useState} from "react";
import {useNavigate} from "react-router-dom"; //useHistory
import axios from "axios";
import classNamesModule from "classnames";
import {AddGroceryItem} from "./AddGroceryItem";
import { Navigate } from "react-router-dom";
const API_BASE_URL = "http://localhost:8080"; //in order not to repeat URL again bcoz it keeps changing

export function GrocerySection(props)
{
    console.log("Props", props);
    //step 2
    const [groceryItems, updateGroceryItems] = useState([]); //store the data from db
    const navigate = useNavigate();
    async function fetchGroceryItems()
    {
        const groceryData = await axios.get(`${API_BASE_URL}/grocery/getAll`);
        console.log("Grocery Data", groceryData);
        console.log(groceryData.data.results);
        const dataFromAPI = groceryData.data.results;
        updateGroceryItems(dataFromAPI); //data from API is stored in groceryItems state variable
    }
    //step 3 : useEfect to make API call only once
    useEffect(() => {
        fetchGroceryItems(); //API call is made only once, so see line 54
    }, []);

     //Make API call to update
     async function handlePurchaseUpdate(item)
     {
         console.log("item in new funct", item);
         const updateData = await axios.put(`${API_BASE_URL}/grocery/updatePurchaseStatus`, {
             "_id" : item._id,
             "isPurchased" : true        
          });
          console.log("Updated data", updateData);
          alert("Items purchase status updated successfully");
          fetchGroceryItems(); //fetch again, no refreshing
     }
 
     //make API call to delete
     async function handleDeleteOperation(item)
     {
         const deleteResponse = await axios.delete(`${API_BASE_URL}/grocery/deleteGroceryItem`, {
             //can't send JSON diectly
             data : {
                 _id : item._id,
             },
         });
         console.log("Delete Response", deleteResponse);
         alert("Item deleted successfully");
         fetchGroceryItems();
     }

     function renderPurchaseButton(item)
     {
         //console.log("item in new funct", item);
         if(item.isPurchased === false)
         {
             return  (
                //  Boostrap spacing between 2 buttons
                 <div className="me-3">
                    <button className="btn btn-success" 
                        onClick={() => handlePurchaseUpdate(item)}>Mark as purchased
                    </button>
                 </div>);
         }
         else
         {
             return <div></div>;
         }
     }



     function renderDeleteButton(item)
     {
        return(
        <div>
            <button className="btn btn-danger" 
            onClick={() => handleDeleteOperation(item)}>
                Delete</button>

        </div>)
     }

    //step 4 : display items
    // function renderGroceryItems()
    // {
    //     return groceryItems.map((item)=>{
    //         console.log("Map function", item);
    //         //step 5 : app.css
    //         return <div className="grocery-item">{item.groceryItem}</div>;
    //     })
    // }


    //Step 4 : Code added for update : linethrough
    // function renderGroceryItems()
    // {
    //     return groceryItems.map((item)=>{
    //         console.log("Map function", item);
    //         //step 5 : app.css
    //         // return <div className="grocery-item purchased">{item.groceryItem}</div>;
    //         //the above statement is line-through for all items, we want only for isPurchased = true, so below syntax

    //         //below write a condition, if item isPurchased = true, then text-decoration: line-through; for purchased class
    //         return <div className={classNamesModule("grocery-item", {
    //             // purchased is class
    //             purchased : item.isPurchased === true,
    //         })}>

    //             {/* OR : 2nd variation : but difficult
    //         return <div className={classNamesModule("grocery-item")}
    //             style = {{textDecoration : item.isPurchased ? "line-through" : "none"}}
    //         > */}

                
    //             {item.groceryItem}
    //             </div>;
    //     })
    // }

    //step 4 : Add button for the users
    function renderGroceryItems()
    {
        return groceryItems.map((item)=>{
            console.log("Map function", item);
            //step 5 : app.css
            // return <div className="grocery-item purchased">{item.groceryItem}</div>;
            //the above statement is line-through for all items, we want only for isPurchased = true, so below syntax

            //below write a condition, if item isPurchased = true, then text-decoration: line-through; for purchased class
            return <div className={classNamesModule("grocery-item d-flex", {
                // purchased is class
                purchased : item.isPurchased === true,
            })}
            //to resolve unique key prop warning
            key={item.groceryItem}
            >

                {/* OR : 2nd variation : but difficult
            return <div className={classNamesModule("grocery-item")}
                style = {{textDecoration : item.isPurchased ? "line-through" : "none"}}
            > */}

                
                <div>{item.groceryItem}</div>
                <div className="grocery-actions d-flex">
                    {/* show the button only if purchase is completed or false, else don't show  : use ternary operator or &&, 
                     if not ternary, write function renderPurchaseButton() above
                    */}
                    
                    {
                        //ternary operator syntax
                        // item.isPurchased === false ?
                        // //  Add css for button 
                        // <button className="btn btn-success" 
                        //      onClick={() => handlePurchaseUpdate()}>Mark as purchased
                        // </button>
                        // : //else
                        // null

                        //&& syntax
                        // item.isPurchased === false &&
                        // //  Add css for button 
                        // <button className="btn btn-success">Mark as purchased</button>   
                    }
                     {/* without ternary operator, use function */}
                        {renderPurchaseButton(item)}

                        {renderDeleteButton(item)}
                    
                </div>
                </div>;
        })
    }

    function handleLogout()
    {
        localStorage.removeItem("user Token");
        navigate("/login");
    }

    return(
        <div className="d-flex justify-content-center align-items-center flex-column w-100">
            <h1>Grocery Planning Section</h1>
            <div className="w-50">
                {/* pass API_BASE_URL as a prop value to child component AddGroceryItem */ 
                /* to make API cal multiple times : pass fetchGroceryItems method in AddGroceryItem component & AddGroceryItem line 20 */}
                <AddGroceryItem baseUrl={API_BASE_URL} fetchGroceryItems={fetchGroceryItems} />
                {/* step 5 */}
                {renderGroceryItems()}
            </div>
            <div>
                <button className={"btn btn-danger mt-4"} 
                onClick={()=>handleLogout()}>
                    Logout
                </button>
            </div>
        </div>
    );
}