import React from "react";
import {Routes, Route, Navigate} from "react-router-dom";
export const PrivateRoute = ({component :  Component, ...rest}) => {
    //const isUserLoggedIn = false; //true/false : check token instead
    //if userToken exists then access internal component, else redirect to home page
    const isUserLoggedIn = localStorage.getItem("user Token");
    return (
        <Routes>
            <Route
            {...rest}
            render={(props) => 
                isUserLoggedIn ? <Component {...props} /> : <Navigate to="/login" />
            }
            />
        </Routes>);
};

//If the user is logged in, redirect to component otherwise redirect to /login
//{...rest} : line 6 :  is like a spread operator : props can be assigned (can be any name propsForComponent)
//render() is an internal method : ternary operator
//const isUserLoggedIn = false; : can't access home page, true can be accessed
//PrivateRoute is accessible only if the user is logged in